# # multiAgents.py
# # --------------
# # Licensing Information:  You are free to use or extend these projects for
# # educational purposes provided that (1) you do not distribute or publish
# # solutions, (2) you retain this notice, and (3) you provide clear
# # attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# #
# # Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# # The core projects and autograders were primarily created by John DeNero
# # (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# # Student side autograding was added by Brad Miller, Nick Hay, and
# # Pieter Abbeel (pabbeel@cs.berkeley.edu).
#
#
# from util import manhattanDistance
# from game import Directions
# import random, util
#
# from game import Agent
#
# class ReflexAgent(Agent):
#     """
#     A reflex agent chooses an action at each choice point by examining
#     its alternatives via a state evaluation function.
#
#     The code below is provided as a guide.  You are welcome to change
#     it in any way you see fit, so long as you don't touch our method
#     headers.
#     """
#
#
#     def getAction(self, gameState):
#         """
#         You do not need to change this method, but you're welcome to.
#
#         getAction chooses among the best options according to the evaluation function.
#
#         Just like in the previous project, getAction takes a GameState and returns
#         some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
#         """
#         # Collect legal moves and successor states
#         legalMoves = gameState.getLegalActions()
#
#         # Choose one of the best actions
#         scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
#         bestScore = max(scores)
#         bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
#         chosenIndex = random.choice(bestIndices) # Pick randomly among the best
#
#         "Add more of your code here if you want to"
#
#         return legalMoves[chosenIndex]
#
#     def evaluationFunction(self, currentGameState, action):
#         """
#         Design a better evaluation function here.
#
#         The evaluation function takes in the current and proposed successor
#         GameStates (pacman.py) and returns a number, where higher numbers are better.
#
#         The code below extracts some useful information from the state, like the
#         remaining food (newFood) and Pacman position after moving (newPos).
#         newScaredTimes holds the number of moves that each ghost will remain
#         scared because of Pacman having eaten a power pellet.
#
#         Print out these variables to see what you're getting, then combine them
#         to create a masterful evaluation function.
#         """
#         # Useful information you can extract from a GameState (pacman.py)
#         successorGameState = currentGameState.generatePacmanSuccessor(action)
#         newPos = successorGameState.getPacmanPosition()
#         newFood = successorGameState.getFood()
#         newGhostStates = successorGameState.getGhostStates()
#         newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
#
#
#         "*** YOUR CODE HERE ***"
#         # print("Game state", successorGameState) #PAC and GHOST and PELLETS in a graph
#         # print("Pos", newPos) #(X,Y)
#         # print("Food", newFood) #TF Matrix
#         # print("Ghost", newGhostStates) #Object at Memeory?
#         # print("Scared timer", newScaredTimes) #[0]
#         # print("Current", currentGameState) #PAC and GHOST and PELLETS in a graph
#         # print("Action", action) #N,E,S,W
#
#         #Mostly same food heuristic from P1 - Passing
#         foodList = newFood.asList()
#         maxDistToFood = 0
#         for food in foodList:
#             distToFood = 1 / manhattanDistance(food, newPos)
#             if distToFood > maxDistToFood:
#                 maxDistToFood = distToFood
#         return successorGameState.getScore() + maxDistToFood
#
# def scoreEvaluationFunction(currentGameState):
#     """
#     This default evaluation function just returns the score of the state.
#     The score is the same one displayed in the Pacman GUI.
#
#     This evaluation function is meant for use with adversarial search agents
#     (not reflex agents).
#     """
#     return currentGameState.getScore()
#
# class MultiAgentSearchAgent(Agent):
#     """
#     This class provides some common elements to all of your
#     multi-agent searchers.  Any methods defined here will be available
#     to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.
#
#     You *do not* need to make any changes here, but you can if you want to
#     add functionality to all your adversarial search agents.  Please do not
#     remove anything, however.
#
#     Note: this is an abstract class: one that should not be instantiated.  It's
#     only partially specified, and designed to be extended.  Agent (game.py)
#     is another abstract class.
#     """
#
#     def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
#         self.index = 0 # Pacman is always agent index 0
#         self.evaluationFunction = util.lookup(evalFn, globals())
#         self.depth = int(depth)
#
# class MinimaxAgent(MultiAgentSearchAgent):
#     """
#     Your minimax agent (question 2)
#     """
#
#     def getAction(self, gameState):
#         """
#         Returns the minimax action from the current gameState using self.depth
#         and self.evaluationFunction.
#
#         Here are some method calls that might be useful when implementing minimax.
#
#         gameState.getLegalActions(agentIndex):
#         Returns a list of legal actions for an agent
#         agentIndex=0 means Pacman, ghosts are >= 1
#
#         gameState.generateSuccessor(agentIndex, action):
#         Returns the successor game state after an agent takes an action
#
#         gameState.getNumAgents():
#         Returns the total number of agents in the game
#
#         gameState.isWin():
#         Returns whether or not the game state is a winning state
#
#         gameState.isLose():
#         Returns whether or not the game state is a losing state
#         """
#         "*** YOUR CODE HERE ***"
#
#         return self.miniMax(gameState, 0, 0, True) # gs, depth, agent, bool
#
#
#     def miniMax(self, gameState, depth, agent, maxFunction):
#         # Return the games score
#         if gameState.isLose() or gameState.isWin():
#             return gameState.getScore()
#
#         valueList = []
#         actionList = []
#         # Max Function
#         if maxFunction:
#             for action in gameState.getLegalActions(0):
#                 child = gameState.generateSuccessor(0, action)
#                 value = self.miniMax(child, depth, 1, False)  # Recursive call to the min function
#                 valueList.append(value)
#                 actionList.append(action)
#             largestVal = max(valueList)
#             i = 0
#             for val in valueList:  # Loop to find corresponding action to the value
#                 if valueList[i] == largestVal:
#                     largestAction = actionList[i]
#                 i = i + 1
#             if depth == 0:
#                 return largestAction
#             else:
#                 return largestVal
#         # Min Function
#         else:
#             totalAgents = gameState.getNumAgents()
#             agentIndex = agent + 1  # >=1 for the ghosts
#             if agent == totalAgents - 1:
#                 agentIndex = 0 # Pacman
#             for action in gameState.getLegalActions(agent):
#                 child = gameState.generateSuccessor(agent, action)
#                 if agentIndex == 0: # Pacman
#                     if depth == self.depth - 1:
#                         value = scoreEvaluationFunction(child)  # Call to eval fx
#                     else:
#                         value = self.miniMax(child, depth + 1, 0, True)  # Recursive call to max
#                 else:
#                     value = self.miniMax(child, depth, agentIndex, False)  # Recursive call to min
#                 valueList.append(value)
#             smallestVal = min(valueList)
#             return smallestVal
#
# class AlphaBetaAgent(MultiAgentSearchAgent):
#     """
#     Your minimax agent with alpha-beta pruning (question 3)
#     """
#
#
#     def getAction(self, gameState):
#         """
#         Returns the minimax action using self.depth and self.evaluationFunction
#         """
#         "*** YOUR CODE HERE ***"
#         # 3,333,360 is the maximum score in a real pacman game
#         print("-----------------------------------------------------------")
#         return self.alphaBetaPruning(gameState, 0, 0, -3333360, 3333360)
#
#     def alphaBetaPruning(self, gameState, depth, agent, alpha, beta):
#
#         # Condition to end the recurrence
#         if gameState.isLose() or gameState.isWin():
#             return gameState.getScore()
#
#         # Set up for generateSuccessor
#         nextAgent = agent + 1
#         if nextAgent == gameState.getNumAgents():
#             nextAgent = 0  # Pacman is next
#
#         scoreList = []
#         actionList = []
#
#         if agent == 0:
#             print("I am the Maximizer")
#             # Initialize 'v'
#             myScore = alpha
#             print("Score = ", myScore)
#             print("(", alpha, ", ", beta, ")")
#             # For every successor
#             for action in gameState.getLegalActions():
#                 # get the successor's score
#                 print("===========================================================")
#                 print(len(gameState.getLegalActions()))
#                 childGameState = gameState.generateSuccessor(nextAgent, action)
#                 print("raaa")
#                 childScore = self.alphaBetaPruning(childGameState, depth, nextAgent, alpha, beta)
#                 print("childScore = ", childScore)
#                 # set up to find the action corresponding to the score if need be
#                 scoreList.append(childScore)
#                 actionList.append(action)
#                 # myScore = max of myScore and successor's score
#                 if childScore > myScore:
#                     myScore = childScore
#                 print("Score = ", myScore)
#                 # if myScore > beta return myScore
#                 if myScore >= beta:
#                     print("Pruning")
#                     return myScore
#                 # alpha = max(alpha, myScore)
#                 if myScore > alpha:
#                     alpha = myScore
#                 print("(", alpha, ", ", beta, ")")
#
#         else:
#             print("I am the Minimizer")
#             # Initialize 'v'
#             myScore = beta
#             print("Score = ", myScore)
#             print("(", alpha, ", ", beta, ")")
#             # For every successor
#             for action in gameState.getLegalActions():
#                 # get the successor's score
#                 print("===========================================================")
#                 childGameState = gameState.generateSuccessor(nextAgent, action)
#                 if nextAgent == 0:  # Pacman is the top of the ply
#                     if depth == self.depth - 1:  # this is as deep as we should go
#                         print("That's deep enough!")
#                         childScore = scoreEvaluationFunction(childGameState)
#                     else:
#                         childScore = self.alphaBetaPruning(childGameState, depth + 1, nextAgent, alpha, beta)
#                 else:
#                     childScore = self.alphaBetaPruning(childGameState, depth, nextAgent, alpha, beta)
#                 print("childScore = ", childScore)
#                 # set up to find the action corresponding to the score if need be
#                 scoreList.append(childScore)
#                 actionList.append(action)
#                 # myScore = min of myScore and successor's score
#                 if childScore < myScore:
#                     myScore = childScore
#                 print("Score = ", myScore)
#                 # if myScore < alpha return myScore
#                 if myScore <= alpha:
#                     print("Pruning")
#                     return myScore
#                 # beta = min(beta, myScore)
#                 if myScore < beta:
#                     beta = myScore
#                 print("(", alpha, ", ", beta, ")")
#
#         # return the best action to the main program or the largest score to the previous ply
#         if agent == 0 and depth == 0:
#             for i in range(len(scoreList)):
#                 if scoreList[i] == myScore:
#                     return actionList[i]
#         else:
#             return myScore
#
# class ExpectimaxAgent(MultiAgentSearchAgent):
#     """
#       Your expectimax agent (question 4)
#     """
#
#     def getAction(self, gameState):
#         """
#         Returns the expectimax action using self.depth and self.evaluationFunction
#
#         All ghosts should be modeled as choosing uniformly at random from their
#         legal moves.
#         """
#         "*** YOUR CODE HERE ***"
#
#         return self.miniMax(gameState, 0, 0, True)  # gs, depth, agent, bool
#
#     def miniMax(self, gameState, depth, agent, maxFunction):
#         # Return the games score
#         if gameState.isLose() or gameState.isWin():
#             return gameState.getScore()
#
#         valueList = []
#         actionList = []
#         # Max Function
#         if maxFunction:
#             for action in gameState.getLegalActions(0):
#                 child = gameState.generateSuccessor(0, action)
#                 value = self.miniMax(child, depth, 1, False)  # Recursive call to the min function
#                 valueList.append(value)
#                 actionList.append(action)
#             largestVal = max(valueList)
#             i = 0
#             for val in valueList:  # Loop to find corresponding action to the value
#                 if valueList[i] == largestVal:
#                     largestAction = actionList[i]
#                 i = i + 1
#             if depth == 0:
#                 return largestAction
#             else:
#                 return largestVal
#         # Min Function
#         else:
#             totalAgents = gameState.getNumAgents()
#             agentIndex = agent + 1  # >=1 for the ghosts
#             if agent == totalAgents - 1:
#                 agentIndex = 0  # Pacman
#             for action in gameState.getLegalActions(agent):
#                 child = gameState.generateSuccessor(agent, action)
#                 if agentIndex == 0:  # Pacman
#                     if depth == self.depth - 1:
#                         value = scoreEvaluationFunction(child)  # Call to eval fx
#                     else:
#                         value = self.miniMax(child, depth + 1, 0, True)  # Recursive call to max
#                 else:
#                     value = self.miniMax(child, depth, agentIndex, False)  # Recursive call to min
#                 valueList.append(value)
#             average = sum(valueList)/len(valueList)
#             return average
#
# def betterEvaluationFunction(currentGameState):
#     """
#     Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
#     evaluation function (question 5).
#
#     DESCRIPTION: Tried my reflex agent and it worked
#     """
#     "*** YOUR CODE HERE ***"
#
#     # Mostly same Q1, just adjusted based on params
#     foodList = currentGameState.getFood().asList()
#     maxDistToFood = 0
#     for food in foodList:
#         distToFood = 1 / manhattanDistance(food, currentGameState.getPacmanPosition())
#         if distToFood > maxDistToFood:
#             maxDistToFood = distToFood
#     return currentGameState.getScore() + maxDistToFood
#
# # Abbreviation
# better = betterEvaluationFunction

# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        foodList = newFood.asList()
        maxDistToFood = 0
        for food in foodList:
            distToFood = 1 / manhattanDistance(food, newPos)
            if distToFood > maxDistToFood:
                maxDistToFood = distToFood
        return successorGameState.getScore() + maxDistToFood


def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        return self.miniMax(gameState, 0, 0)  # gs, depth, agent, max?

    def miniMax(self, gameState, depth, agent):
        # Return the games score
        if gameState.isLose() or gameState.isWin():
            return gameState.getScore()

        scoreList = []
        actionList = []
        # Max Function (I am Pacman)
        if agent == 0:
            # Generate actions and their evaluated scores
            for action in gameState.getLegalActions(0):
                childGameState = gameState.generateSuccessor(0, action)
                childScore = self.miniMax(childGameState, depth, 1)  # Recursive call to the min function
                scoreList.append(childScore)
                actionList.append(action)

            # find highest-scoring action
            largestScore = scoreList[0]
            largestAction = actionList[0]
            for i in range(len(scoreList)):
                if scoreList[i] > largestScore:
                    largestScore = scoreList[i]
                    largestAction = actionList[i]

            # return the best action to the main program but return largest score to the previous ply
            if depth == 0:
                return largestAction
            else:
                return largestScore
        # Min Function
        else:
            nextAgent = agent + 1  # >=1 for the ghosts
            if nextAgent == gameState.getNumAgents():
                nextAgent = 0  # Pacman is next

            # Generate actions and their evaluated scores
            for action in gameState.getLegalActions(agent):
                childGameState = gameState.generateSuccessor(agent, action)
                if nextAgent == 0:  # Pacman is next (AKA everyone has taken a turn this ply)
                    if depth == self.depth - 1:  # this is as deep as we should go
                        childScore = scoreEvaluationFunction(childGameState)
                    else:
                        childScore = self.miniMax(childGameState, depth + 1, 0)  # Recursive call to max
                else:  # a ghost is next
                    childScore = self.miniMax(childGameState, depth, nextAgent)  # Recursive call to min
                scoreList.append(childScore)

            # Min evaluates to minimum possible action
            return min(scoreList)


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        # 3,333,360 is the maximum score in a real pacman game
        print("-----------------------------------------------------------")
        return self.alphaBetaPruning(gameState, 0, 0, -3333360, 3333360)

    def alphaBetaPruning(self, gameState, depth, agent, alpha, beta):

        # Condition to end the recurrence
        if gameState.isLose() or gameState.isWin():
            return gameState.getScore()

        # Set up for generateSuccessor
        nextAgent = agent + 1
        if nextAgent == gameState.getNumAgents():
            nextAgent = 0  # Pacman is next

        scoreList = []
        actionList = []

        if agent == 0:
            print("I am Pacman, agent = ", agent)
            # Initialize 'v'
            myScore = alpha
            # print("Score = ", myScore)
            # print("(", alpha, ", ", beta, ")")
            # For every successor
            for action in gameState.getLegalActions(agent):
                # get the successor's score
                # print("===========================================================")
                # print(action)
                childGameState = gameState.generateSuccessor(agent, action)
                childScore = self.alphaBetaPruning(childGameState, depth, nextAgent, alpha, beta)
                # print("childScore = ", childScore)
                # set up to find the action corresponding to the score if need be
                scoreList.append(childScore)
                actionList.append(action)
                # myScore = max of myScore and successor's score
                if childScore > myScore:
                    myScore = childScore
                # print("Score = ", myScore)
                # if myScore > beta return myScore
                if myScore > beta:
                    print("Pruning remaining children, agent = ", agent)
                    return myScore
                # alpha = max(alpha, myScore)
                if myScore > alpha:
                    alpha = myScore
                # print("(", alpha, ", ", beta, ")")

        else:
            print("I am a Ghost, agent = ", agent)
            # Initialize 'v'
            myScore = beta
            # print("Score = ", myScore)
            # print("(", alpha, ", ", beta, ")")
            # For every successor
            for action in gameState.getLegalActions(agent):
                # get the successor's score
                # print("===========================================================")
                childGameState = gameState.generateSuccessor(agent, action)
                if nextAgent == 0:  # Pacman is the top of the ply
                    if depth == self.depth - 1:  # this is as deep as we should go
                        print("That's deep enough!")
                        childScore = scoreEvaluationFunction(childGameState)
                    else:
                        childScore = self.alphaBetaPruning(childGameState, depth+1, nextAgent, alpha, beta)
                else:
                    childScore = self.alphaBetaPruning(childGameState, depth, nextAgent, alpha, beta)
                # print("childScore = ", childScore)
                # set up to find the action corresponding to the score if need be
                scoreList.append(childScore)
                actionList.append(action)
                # myScore = min of myScore and successor's score
                if childScore < myScore:
                    myScore = childScore
                # print("Score = ", myScore)
                # if myScore < alpha return myScore
                if myScore < alpha:
                    print("Pruning remaining children, agent = ", agent)
                    return myScore
                # beta = min(beta, myScore)
                if myScore < beta:
                    beta = myScore
                # print("(", alpha, ", ", beta, ")")

        # return the best action to the main program or the largest score to the previous ply
        if agent == 0 and depth == 0:
            for i in range(len(scoreList)):
                if scoreList[i] == myScore:
                    return actionList[i]
        else:
            return myScore


class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        return self.miniMax(gameState, 0, 0)  # gs, depth, agent, max?

    def miniMax(self, gameState, depth, agent):
        # Return the games score
        if gameState.isLose() or gameState.isWin():
            return gameState.getScore()

        scoreList = []
        actionList = []
        # Max Function (I am Pacman)
        if agent == 0:
            # Generate actions and their evaluated scores
            for action in gameState.getLegalActions(0):
                childGameState = gameState.generateSuccessor(0, action)
                childScore = self.miniMax(childGameState, depth, 1)  # Recursive call to the min function
                scoreList.append(childScore)
                actionList.append(action)

            # find highest-scoring action
            largestScore = scoreList[0]
            largestAction = actionList[0]
            for i in range(len(scoreList)):
                if scoreList[i] > largestScore:
                    largestScore = scoreList[i]
                    largestAction = actionList[i]

            # return the best action to the main program but return largest score to the previous ply
            if depth == 0:
                return largestAction
            else:
                return largestScore
        # Min Function
        else:
            nextAgent = agent + 1  # >=1 for the ghosts
            if nextAgent == gameState.getNumAgents():
                nextAgent = 0  # Pacman is next

            # Generate actions and their evaluated scores
            for action in gameState.getLegalActions(agent):
                childGameState = gameState.generateSuccessor(agent, action)
                if nextAgent == 0:  # Pacman is next (AKA everyone has taken a turn this ply)
                    if depth == self.depth - 1:  # this is as deep as we should go
                        childScore = scoreEvaluationFunction(childGameState)
                    else:
                        childScore = self.miniMax(childGameState, depth + 1, 0)  # Recursive call to max
                else:  # a ghost is next
                    childScore = self.miniMax(childGameState, depth, nextAgent)  # Recursive call to min
                scoreList.append(childScore)

            # Min evaluates to minimum possible action
            return sum(scoreList)/len(scoreList)


def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    # Mostly same Q1, just adjusted based on params
    # foodList = currentGameState.getFood().asList()
    # maxDistToFood = 999999
    # for food in foodList:
    #     distToFood = manhattanDistance(food, currentGameState.getPacmanPosition())
    #     if distToFood < maxDistToFood:
    #         maxDistToFood = distToFood
    #
    # ghostList = currentGameState.getGhostPositions().asList()
    # minDistToGhost = 99999
    # for ghost in ghostList:
    #     distToGhost = manhattanDistance(currentGameState.getPacmanPosition, ghost)
    #     if distToGhost < minDistToGhost:
    #         minDistToGhost = distToGhost
    #
    # return minDistToGhost - maxDistToFood
    foodList = currentGameState.getFood().asList()
    maxDistToFood = 0
    for food in foodList:
        distToFood = 1 / manhattanDistance(food, currentGameState.getPacmanPosition())
        if distToFood > maxDistToFood:
            maxDistToFood = distToFood
    return currentGameState.getScore() + maxDistToFood

# Abbreviation
better = betterEvaluationFunction
